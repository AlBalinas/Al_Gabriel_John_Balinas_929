import 'package:flutter/material.dart';
import 'package:widgets/components/globalappbar_component.dart';

class Newsfeedcomponent extends StatelessWidget {
  final String? username;
  final String? timeposted; // Requirement 3
  final String? status;
  final String? numberoflikes;
  final String? numberofcomments;
  final String? numberofshares;

  const Newsfeedcomponent({
    super.key,
    this.username,
    this.timeposted, // Requirement 3
    this.status,
    this.numberoflikes,
    this.numberofcomments,
    this.numberofshares,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Profile Header
          ListTile(
            leading: const CircleAvatar(
              child: Icon(Icons.face), // Requirement 2: Changed profile icon
            ),
            title: Text(username ?? "John Doe"),
            subtitle: Text(
              timeposted ?? "Just now",
            ), // Requirement 3: Added timeposted under username
            trailing: const Icon(Icons.more_vert),
          ),

          // Part 9 Challenge: Status displayed above the image
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              status ?? "This is a sample status.",
              style: const TextStyle(fontSize: 16),
            ),
          ),

          const SizedBox(height: 15),

          // Image Placeholder Area
          Container(
            width: double.infinity,
            height: 330,
            decoration: const BoxDecoration(
              color: Colors
                  .indigoAccent, // Requirement 1: Changed background color
            ),
            child: const Center(
              child: Icon(Icons.image, size: 80, color: Colors.white),
            ),
          ),

          // Engagement Footer
          ListTile(
            leading: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.thumb_up_alt_outlined),
                const SizedBox(width: 5),
                Text(numberoflikes ?? "0"),
              ],
            ),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.comment_outlined),
                const SizedBox(width: 5),
                Text(numberofcomments ?? "0"),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.share_outlined),
                const SizedBox(width: 5),
                Text(numberofshares ?? "0"),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class NewsfeedScreen extends StatefulWidget {
  const NewsfeedScreen({super.key});

  @override
  State<NewsfeedScreen> createState() => _NewsfeedScreenState();
}

class _NewsfeedScreenState extends State<NewsfeedScreen> {
  // Requirement 4: Expanded newsfeed list with 8 posts and timeposted fields
  final List<Map<String, String>> newsfeed = [
    {
      "username": "John Doe",
      "timeposted": "2 hours ago",
      "status": "Having a great day!",
      "likes": "120",
      "comments": "25",
      "shares": "10",
    },
    {
      "username": "Jane Smith",
      "timeposted": "3 hours ago",
      "status": "Learning Flutter is fun!",
      "likes": "250",
      "comments": "40",
      "shares": "15",
    },
    {
      "username": "Michael Cruz",
      "timeposted": "5 hours ago",
      "status": "Working on my new project.",
      "likes": "89",
      "comments": "12",
      "shares": "4",
    },
    {
      "username": "Alex Santos",
      "timeposted": "Yesterday at 4:15 PM",
      "status": "Flutter development today!",
      "likes": "300",
      "comments": "50",
      "shares": "20",
    },
    {
      "username": "Maria Clara",
      "timeposted": "1 day ago",
      "status": "Coffee, code, and continuous learning.",
      "likes": "412",
      "comments": "38",
      "shares": "18",
    },
    {
      "username": "Crisostomo Ibarra",
      "timeposted": "2 days ago",
      "status": "Building scalable mobile apps with reusable widgets.",
      "likes": "185",
      "comments": "19",
      "shares": "7",
    },
    {
      "username": "David Miller",
      "timeposted": "3 days ago",
      "status": "Debugging state management issues all morning!",
      "likes": "94",
      "comments": "31",
      "shares": "3",
    },
    {
      "username": "Sophia Reyes",
      "timeposted": "4 days ago",
      "status": "Just published my first custom Flutter component!",
      "likes": "520",
      "comments": "64",
      "shares": "42",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: GlobalappbarComponent(),
      body: ListView.builder(
        padding: const EdgeInsets.all(10),
        itemCount: newsfeed.length,
        itemBuilder: (context, index) {
          final post = newsfeed[index];

          return Newsfeedcomponent(
            username: post["username"],
            timeposted: post["timeposted"], // Requirement 3
            status: post["status"],
            numberoflikes: post["likes"],
            numberofcomments: post["comments"],
            numberofshares: post["shares"],
          );
        },
      ),
    );
  }
}
