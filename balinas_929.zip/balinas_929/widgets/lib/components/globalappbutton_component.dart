import 'package:flutter/material.dart';

class GlobalappbuttonComponent extends StatelessWidget {
  const GlobalappbuttonComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return TextButton(onPressed: () {}, child: Text("Button"));
  }
}
