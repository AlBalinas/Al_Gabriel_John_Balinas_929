import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const Color facebookBlue = Color(0xFF0866FF);
  static const Color lightGrey = Color(0xFFF0F2F5);
  static const Color darkGrey = Color(0xFF65676B);

  Widget circleIcon(IconData icon, {double size = 20}) {
    return Container(
      width: 36,
      height: 36,
      decoration: const BoxDecoration(
        color: lightGrey,
        shape: BoxShape.circle,
      ),
      child: Icon(icon, size: size, color: Colors.black),
    );
  }

  Widget actionButton(String text, IconData icon, {bool primary = false}) {
    return Expanded(
      child: Container(
        height: 38,
        decoration: BoxDecoration(
          color: primary ? facebookBlue : lightGrey,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 18,
              color: primary ? Colors.white : Colors.black,
            ),
            const SizedBox(width: 6),
            Text(
              text,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: primary ? Colors.white : Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget detailRow(IconData icon, String text, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: darkGrey, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 15,
                fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text('Profile', 
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 24)),
        actions: [
          circleIcon(Icons.search),
          const SizedBox(width: 8),
          circleIcon(Icons.more_horiz),
          const SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            SizedBox(
              height: 200, 
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  
                  Container(
                    height: 150,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: NetworkImage('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=800'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  
                  Positioned(
                    left: 16,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: const CircleAvatar(
                        radius: 60,

                      ),
                    ),
                  ),
                  
                  Positioned(
                    left: 95,
                    bottom: 5,
                    child: circleIcon(Icons.camera_alt, size: 18),
                  ),
                 
                  Positioned(
                    right: 12,
                    top: 110,
                    child: circleIcon(Icons.camera_alt, size: 18),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Al Balinas',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  const Text(
                    '125 friends',
                    style: TextStyle(color: darkGrey, fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      actionButton('Add to story', Icons.add_circle, primary: true),
                      const SizedBox(width: 8),
                      actionButton('Edit profile', Icons.edit),
                      const SizedBox(width: 8),
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(color: lightGrey, borderRadius: BorderRadius.circular(8)),
                        child: const Icon(Icons.more_horiz),
                      )
                    ],
                  ),
                ],
              ),
            ),

            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Divider(thickness: 1),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  detailRow(Icons.work, 'Works at Krusty Krab'),
                  detailRow(Icons.school, 'Studied at Central Philippine University'),
                  detailRow(Icons.home, 'Lives in Oton, Iloilo'),
                  detailRow(Icons.location_on, 'From Iloilo City'),
                  detailRow(Icons.cake, 'Febuary 20, 2006'),
                  detailRow(Icons.more_horiz, 'See your About info', isBold: false),
                ],
              ),
            ),

            const SizedBox(height: 10),
            const Divider(thickness: 6, color: lightGrey),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Posts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text('Filters', style: TextStyle(color: facebookBlue, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
