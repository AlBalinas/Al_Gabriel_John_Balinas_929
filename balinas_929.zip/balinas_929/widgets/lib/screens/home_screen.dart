import 'package:flutter/material.dart';
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Text("Hello, World!"),
          SizedBox(width: 50),
          Text("Welcome to the Home Screen"),

          Row(
            children: [
              Text(
                "bubilatibay",
                style: TextStyle(
                  color: const Color.fromARGB(255, 223, 173, 12),
                ),
              ),
              SizedBox(width: 50),
              Text(
                "How are you?",
                style: TextStyle(color: const Color.fromARGB(255, 167, 10, 10)),
              ),
            ],
          ),
          Container(
            height: 250,
            width: 250,
            color: Colors.indigo,
            child: Center(child: Text("Hello World")),
          ),
        ],
      ),
    );
  }
}
