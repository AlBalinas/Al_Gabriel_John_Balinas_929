import 'package:flutter/material.dart';

class PrelimScreen extends StatefulWidget {
  const PrelimScreen({super.key});

  @override
  State<PrelimScreen> createState() => _PrelimScreenState();
}

class _PrelimScreenState extends State<PrelimScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Title
            const Text(
              'Prelim Exam',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // Subtitle / Name
            const Text(
              'Al Gabriel John C. Balinas',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 25),

            // Top Box (BOX 1)
            Container(
              width: 170,
              height: 170,
              color: Colors.blue,
              alignment: Alignment.center,
              child: const Text(
                'BOX 1',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 25),

            // Bottom Boxes (BOX 2 and BOX 3)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 170,
                  height: 170,
                  color: Colors.blue,
                  alignment: Alignment.center,
                  child: const Text(
                    'BOX 2',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 25),
                Container(
                  width: 170,
                  height: 170,
                  color: Colors.blue,
                  alignment: Alignment.center,
                  child: const Text(
                    'BOX 3',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
